a = [4,7,3,2,5,9]

for i in range(len(a)):
	print("Element : %i and it's position : %i" % (a[i],i))