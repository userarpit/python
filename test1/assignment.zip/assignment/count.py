word = input("Enter input - ")
counter={}
for letter in word:
	if letter not in counter:
		counter[letter] = 0
	counter[letter] += 1

print(counter)