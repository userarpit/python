list1=[1,3,6,78,35,55,88]
list2=[12,24,35,24,88,120,155]

result = [i for i in list1 if i in list2]
print(result)