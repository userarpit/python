lis1 = [12,24,35,24,88,120,155]
no_24 = [x for x in lis1 if x != 24]
print(no_24)
