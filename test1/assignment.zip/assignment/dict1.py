d= {"john":40, "peter":45}
print(list(d.keys()))