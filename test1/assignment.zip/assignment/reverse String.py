#Program to reverse a string
gfg = "Arpit Khandelwal"
print(gfg[::-1])

print("".join(reversed(gfg)))

str1 = "Arpit Khandelwal"

print(str1[-10:10])

list1 = list(str1)
list1[2]='e'

print("".join(list1))