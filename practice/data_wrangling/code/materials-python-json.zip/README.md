# Working With JSON Data in Python 

This folder provides the code examples for the article [Working With JSON Data in Python](https://realpython.com/python-json).
